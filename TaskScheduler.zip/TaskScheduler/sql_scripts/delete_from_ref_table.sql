DELETE FROM `project_table`.`ref_table` WHERE (`reference_id` = '1');
DELETE FROM `project_table`.`ref_table` WHERE (`reference_id` = '2');
DELETE FROM `project_table`.`ref_table` WHERE (`reference_id` = '3');
DELETE FROM `project_table`.`ref_table` WHERE (`reference_id` = '4');
DELETE FROM `project_table`.`ref_table` WHERE (`reference_id` = '5');
DELETE FROM `project_table`.`ref_table` WHERE (`reference_id` = '6');
DELETE FROM `project_table`.`ref_table` WHERE (`reference_id` = '7');

