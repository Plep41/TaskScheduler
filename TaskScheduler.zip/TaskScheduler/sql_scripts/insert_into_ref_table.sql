INSERT INTO `project_table`.`ref_table`
(`reference_id`,
`ref_desc`,
`ref_name`,
`sequence_id`)
VALUES
('1', 'stage involves identifying the system’s objectives, defining the scope, setting timelines, and allocating necessary resources.', 'Planning', '1'
),
('2', 'This involves gathering input from stakeholders, reviewing current processes, and identifying the system’s needs.', 'Analysis', '2'
),
('3', 'includes designing the system’s architecture, database models, user interfaces, and defining system components.', 'Design', '3'
),
('4', 'Developers build the system according to the design specifications, implementing features, creating databases, and writing code. ', 'Development', '4'
),
('5', 'phase includes multiple types of testing, such as unit testing, integration testing, system testing, and user acceptance testing.', 'Testing', '5'
),
('6', 'Key activities include system installation, migrating data, training users, and configuring infrastructure. ', 'Implementation', '6'
),
('7', 'This includes bug fixes, performance enhancements, security patches, and responding to user feedback.', 'Maintenance', '7'
);
