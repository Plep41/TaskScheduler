drop database if exists `project_table` cascade;

CREATE DATABASE `project_table` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

    drop table if exists project cascade;
    
    drop table if exists ref_table cascade;
        
    drop table if exists task cascade;
	
CREATE TABLE `project` (
  `duration` int DEFAULT NULL,
  `projectid` int NOT NULL AUTO_INCREMENT,
  `project_end_date` datetime(6) DEFAULT NULL,
  `project_start_date` datetime(6) DEFAULT NULL,
  `project_desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`projectid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `ref_table` (
  `reference_id` int NOT NULL AUTO_INCREMENT,
  `sequence_id` int DEFAULT NULL,
  `ref_desc` varchar(255) DEFAULT NULL,
  `ref_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`reference_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `task` (
  `duration` int DEFAULT NULL,
  `sequence_id` int DEFAULT NULL,
  `taskid` int NOT NULL AUTO_INCREMENT,
  `task_end_date` datetime(6) DEFAULT NULL,
  `task_start_date` datetime(6) DEFAULT NULL,
  `dependency` varchar(255) DEFAULT NULL,
  `task_desc` varchar(255) DEFAULT NULL,
  `phase` varchar(255) DEFAULT NULL,
  `project_desc` varchar(255) DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  PRIMARY KEY (`taskid`),
  KEY `FKk8qrwowg31kx7hp93sru1pdqa` (`project_id`),
  CONSTRAINT `FKk8qrwowg31kx7hp93sru1pdqa` FOREIGN KEY (`project_id`) REFERENCES `project` (`projectid`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


