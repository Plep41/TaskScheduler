package com.bpi.TaskScheduler.Controller;

import com.bpi.TaskScheduler.Entities.Project;
import com.bpi.TaskScheduler.Entities.Task;
import com.bpi.TaskScheduler.Repository.ProjectRepository;
import com.bpi.TaskScheduler.Repository.TaskRepository;
import com.bpi.TaskScheduler.utilities.DateUtilities;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Comparator;
import java.util.Date;
import java.util.List;

import static com.bpi.TaskScheduler.utilities.DateUtilities.addDate;

@RestController
public class ProjectController {

    @Autowired
    ProjectRepository projRepo;

    @Autowired
    TaskRepository taskRepo;

    //get all project values.
    //localhost:8080/projects
    @GetMapping("/projects")
    public List<Project> getAllProjects() {

        List<Project> projects = projRepo.findAll();
        return projects;
    }

    //get all project values.
    //localhost:8080/projects
    @GetMapping("/project/{id}")
    public List<Task> getProject(@PathVariable int id) {

        List<Task> filteredTaskList = taskRepo.findAll().stream()
                .filter(task -> task.getProjectID().matches(String.valueOf(id))).sorted(Comparator.comparing(Task::getSequenceId))
                .toList();

        return filteredTaskList;
    }

    //localhost:8080/project/updateTaskDetails/{id}
    @PutMapping("/project/updateTaskDetails/{id}")
    public List<Task> updateTaskDetails(@PathVariable int id) {

        Project project = projRepo.findById(id).get();
        Date nextTaskStartDate = project.getProjectStartDate();
        Date projEndDate = project.getProjectEndDate();
        List<Task> filteredTaskList = taskRepo.findAll().stream()
                .filter(task -> task.getProjectID().matches(String.valueOf(id))).sorted(Comparator.comparing(Task::getSequenceId))
                .toList();

        for (Task task : filteredTaskList) {
            String tskStartDate = "";
            int duration = task.getDuration();
            String dependency = task.getDependency();
            Date taskStartDate, taskEndDate;

            if(dependency.trim().equals("")) {
                taskStartDate = project.getProjectStartDate();
                tskStartDate = DateUtilities.strDateFormatter1(String.valueOf(taskStartDate));
            } else {
                taskStartDate = nextTaskStartDate;
                tskStartDate = DateUtilities.strDateFormatter2(String.valueOf(taskStartDate));
            }


            taskEndDate = addDate(tskStartDate, duration);

            String nxtTaskStartDate = DateUtilities.strDateFormatter2(String.valueOf(taskEndDate));
            nextTaskStartDate = addDate(nxtTaskStartDate, 2);

            task.setTaskStartDate(taskStartDate);
            task.setTaskEndDate(taskEndDate);
            projEndDate = taskEndDate;

            taskRepo.save(task);
        }
        project.setProjectEndDate(projEndDate);
        projRepo.save(project);

        filteredTaskList = taskRepo.findAll().stream()
                .filter(task -> task.getProjectID().matches(String.valueOf(id))).sorted(Comparator.comparing(Task::getSequenceId))
                .toList();

        return filteredTaskList;
    }

    //localhost:8080/project/add
    @PostMapping("/project/add")
    public void createProject(@RequestBody Project project) {
        projRepo.save(project);
    }
}
