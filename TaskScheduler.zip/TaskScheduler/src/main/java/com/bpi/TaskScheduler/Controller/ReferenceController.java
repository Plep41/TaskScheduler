package com.bpi.TaskScheduler.Controller;

import com.bpi.TaskScheduler.Entities.Reference;
import com.bpi.TaskScheduler.Repository.ReferenceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ReferenceController {

    @Autowired
    ReferenceRepository repo;

    //get all Reference table values.
    //localhost:8080/references
    @GetMapping("/getReferences")
    public List<Reference> getAllReferences() {

        List<Reference> references = repo.findAll();
        return references;
    }
}
