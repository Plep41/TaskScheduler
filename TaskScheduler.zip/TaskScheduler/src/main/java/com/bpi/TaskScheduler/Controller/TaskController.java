package com.bpi.TaskScheduler.Controller;

import com.bpi.TaskScheduler.Entities.Task;
import com.bpi.TaskScheduler.Repository.ProjectRepository;
import com.bpi.TaskScheduler.Repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

import static com.bpi.TaskScheduler.utilities.DateUtilities.addDate;

@RestController
public class TaskController {

    @Autowired
    TaskRepository taskRepo;

    @Autowired
    ProjectRepository projRepo;

    //get all tasks
    //localhost:8080/tasks
    @GetMapping("/tasks")
    public List<Task> getAllTasks(){

        List<Task> tasks = taskRepo.findAll();

        return tasks;
    }

    //localhost:8080/task/1
    @GetMapping("/task/{id}")
    public Task getTask(@PathVariable int id){

        Task task = taskRepo.findById(id).get();

        return task;
    }

    //localhost:8080/task/add
    @PostMapping("/task/add")
    public void createTask(@RequestBody Task task) {
        taskRepo.save(task);
    }

    //localhost:8080/task/add
    @PostMapping("/tasks/add")
    public List<Task> createTasks(@RequestBody List<Task> tasks) {
        //List<Task> tasks = taskRepo.saveAll(List.of(task));

        return taskRepo.saveAll(tasks);
    }

    //localhost:8080/task/update
    @PutMapping("/task/update")
    public Task updateTask(@RequestBody Task task) {
        taskRepo.save(task);
        return task;
    }

    //localhost:8080/task/updateEndDate/{id}
    @PutMapping("/task/updateEndDate/{id}")
    public Task updateTask(@PathVariable int id) {
        Task task = taskRepo.findById(id).get();
        int duration = task.getDuration();
        Date taskStartDate = task.getTaskStartDate();
        Date taskEndDate = addDate(taskStartDate.toString(), duration);

        task.setTaskEndDate(taskEndDate);
        taskRepo.save(task);

        return task;
    }

    //localhost:8080/task/delete/{id}
    @DeleteMapping("/task/delete/{id}")
    public void delete(@PathVariable int id){
        Task task = taskRepo.findById(id).get();
        taskRepo.delete(task);
    }

    //localhost:8080/task/delete/{id}
    @DeleteMapping("/task/delete")
    public void deleteAllTasks(){

        taskRepo.deleteAll();
    }
}
