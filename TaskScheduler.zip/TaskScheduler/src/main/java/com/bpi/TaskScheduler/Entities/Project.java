package com.bpi.TaskScheduler.Entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.jackson.JsonComponent;

import java.util.Date;


@Entity
@Data
@Table(name = "project")
@JsonComponent
@NoArgsConstructor
@AllArgsConstructor
public class Project {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int projectID;
    @Column
    private int duration;
    @Column (name = "project_desc", nullable = false, unique = true)
    private String projectDesc;
    @Column (name = "project_start_date")
    private Date projectStartDate;
    @Column (name = "project_end_date")
    private Date projectEndDate;

//    @OneToMany(mappedBy = "idOfProject")
//    List<Task> tasks;

    @Override
    public String toString() {
        return "Project{" +
                "projectID=" + projectID +
                ", duration=" + duration +
                ", projectDesc='" + projectDesc + '\'' +
                ", projectStartDate=" + projectStartDate +
                ", projectEndDate=" + projectEndDate +
                '}';
    }
}
