package com.bpi.TaskScheduler.Entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "ref_table")
@NoArgsConstructor
@AllArgsConstructor
public class Reference {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (name = "reference_id")
    private int refID;
    @Column (name = "sequence_id")
    private int sequenceId;
    @Column (name = "ref_name")
    private String refName;
    @Column (name = "ref_desc")
    private String refDesc;

    @Override
    public String toString() {
        return "Reference{" +
                "refID=" + refID +
                ", sequenceId=" + sequenceId +
                ", refName='" + refName + '\'' +
                ", refDesc='" + refDesc + '\'' +
                '}';
    }
}
