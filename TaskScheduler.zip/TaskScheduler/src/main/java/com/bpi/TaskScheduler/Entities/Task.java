package com.bpi.TaskScheduler.Entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Data
@Table(name = "task")
@NoArgsConstructor
@AllArgsConstructor
public class Task {

    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private int taskID;

    @Column (name = "project_id", nullable = false)
    private String projectID;
    @Column (name = "project_desc", nullable = false)
    private String projectDesc;
    @Column (name = "sequence_id", nullable = false)
    private int sequenceId;
    @Column
    private int duration;
    @Column (name = "task_desc")
    private String taskDesc;
    @Column (nullable = false)
    private String phase;
    @Column (name = "task_start_date")
    private Date taskStartDate;
    @Column (name = "task_end_date")
    private Date taskEndDate;
    @Column
    private String dependency;

//    @ManyToOne
//    @JoinColumn(name = "project_id")
//    com.bpi.TaskScheduler.Entities.Project idOfProject;

    @Override
    public String toString() {
        return "Task{" +
                "taskID=" + taskID +
                //", idOfProject=" + idOfProject +
                ", projectID=" + projectID +
                ", projectDesc=" + projectDesc +
                ", sequenceId=" + sequenceId +
                ", duration=" + duration +
                ", taskDesc='" + taskDesc + '\'' +
                ", phase='" + phase + '\'' +
                ", taskStartDate=" + taskStartDate +
                ", taskEndDate=" + taskEndDate +
                ", dependency='" + dependency + '\'' +
                '}';
    }

}
