package com.bpi.TaskScheduler.Repository;

import com.bpi.TaskScheduler.Entities.Reference;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReferenceRepository extends JpaRepository<Reference, Integer> {

}
