package com.bpi.TaskScheduler.utilities;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtilities {

    //    addDate method accepts parameters String Date in 'YYYY-MM-DD' and an integer.
    public static Date addDate(String prevDate, int manDays) {

        Date myDate = null;
        try {
            // Date should be in 'dd-MM-yyyy' format e.g. 23-02-2024.
            myDate = new SimpleDateFormat("dd-MM-yyyy").parse(prevDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        int intDate = DateToDays(myDate);

        intDate += manDays;

        Date neoDate = DaysToDate(intDate);

        System.out.println("\n" + neoDate + " is the date after adding " + manDays + " days.");
        //return newDate;
        return neoDate;
    }

    // format string date from "yyyy-MM-dd HH:mm:ssZ" to "dd-MM-yyyy".
    public static String strDateFormatter1(String mDate) {

        String formattedDate = "", yearStr = "", monthStr= "", dayStr = "";
        String firstPattern = " ";
        String[] srcDate = mDate.split(firstPattern);

        String secondPattern = "-";
        String[] item = srcDate[0].split(secondPattern);

        if (item.length == 3) {

            yearStr = item[0];
            monthStr = item[1];
            dayStr = item[2];

            formattedDate = dayStr + "-" + monthStr + "-" + yearStr;

        }

        return formattedDate;

    }

        // format string date from "Mon Nov 04 00:00:00 PST 2024" to dd-MM-YYYY
    public static String strDateFormatter2(String mdate) {

        String formattedDate = "", monthInt = "";
        String pattern = " ";
        String[] items = mdate.split(pattern);

        if (items.length == 6) {
            String valDayOfWk = items[0]; // value weekdays
            String valMonth = items[1]; // value months
            String valDay = items[2]; // value days
            String valTime = items[3]; // value time
            String valTimeZone = items[4]; // value timezone
            String valYear = items[5]; // value year

            switch (valMonth.toLowerCase()) {
                case "january":
                case "jan":
                    monthInt = "01";
                    break;

                case "febuary":
                case "feb":
                    monthInt = "02";
                    break;

                case "march":
                case "mar":
                    monthInt = "03";
                    break;

                case "april":
                case "apr":
                    monthInt = "04";
                    break;

                case "may":
                    monthInt = "05";
                    break;

                case "june":
                case "jun":
                    monthInt = "06";
                    break;

                case "july":
                case "jul":
                    monthInt = "07";
                    break;

                case "august":
                case "aug":
                    monthInt = "08";
                    break;

                case "september":
                case "sep":
                case "sept":
                    monthInt = "09";
                    break;

                case "october":
                case "oct":
                    monthInt = "10";
                    break;

                case "november":
                case "nov":
                    monthInt = "11";
                    break;

                case "december":
                case "dec":
                    monthInt = "12";
                    break;
            }

            formattedDate = valDay + "-" + monthInt + "-" + valYear;

        }
        return formattedDate;
    }

    public static final long MAGIC=86400000L;

    public static int DateToDays(Date date){
        return (int) (date.getTime()/MAGIC);
    }

    public static Date DaysToDate(int days) {
        return new Date((long) days*MAGIC);
    }

    @Override
    public String toString() {
        return "DateUtilities{}";
    }

}





